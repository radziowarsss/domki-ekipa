# Domki Ekipa — kinowe intro + premium polish (paczka do wgrania)

Cztery pliki. **Wszystkie trafiają do `src/`** w Twoim repo `domki-ekipa`.

| plik z paczki | wrzuć do | co to |
|---|---|---|
| `Intro.tsx`  | `src/Intro.tsx`  | **NOWY** — kinowe, animowane intro (fantasy) |
| `App.tsx`    | `src/App.tsx`    | podpięcie intro (`showIntro` + localStorage + „▶ Odtwórz ponownie") + premium styl |
| `effects.tsx`| `src/effects.tsx`| tło: delikatne iskry zamiast emoji (reszta bez zmian) |
| `index.css`  | `src/index.css`  | style intro + drobny polish |

`package.json` **nie zmieniony** — intro jest na czystym CSS + `<canvas>`, **zero nowych zależności** (żeby build był 100% pewny; framer-motion niepotrzebny).
Backend (`netlify/functions/api.mts`, `src/api.ts`), dane, `types.ts`, `main.tsx` — **nie ruszane**.

## Wgranie (Windows / PowerShell)

```powershell
cd C:\Users\radzi\Downloads\domki-ekipa

# 1) Podmień 4 pliki w src/ na te z paczki (skopiuj/nadpisz).

# 2) Sanity — build MUSI być zielony:
npm run build          # = seed && tsc --noEmit && vite build

# 3) Commit + push (Netlify zbuduje sam z brancha master):
git add src/Intro.tsx src/App.tsx src/effects.tsx src/index.css
git commit -m "feat: kinowe intro (fantasy) + premium UI polish"
git push origin master
```

## Podgląd bez builda
- Otwórz `intro-preview.html` (z tej paczki/projektu) w Chrome — animacje grają od razu.
- Albo `npm run dev` i wejdź na apkę.

## Jak działa intro
- Leci **przy pierwszym wejściu** (telefon i desktop). Po obejrzeniu/pominięciu zapisuje `domki_intro_seen` w `localStorage` → następnym razem nie leci.
- Ponowne odtworzenie: przycisk **„▶ Odtwórz intro ponownie"** w stopce apki.
- Sterowanie: auto-play, **tap/klik = dalej**, **„Pomiń ⏭"**, klawiatura (→ / Enter / Esc), opcjonalny **dźwięk** (domyślnie off).
- 5 scen: Prolog → Akt I (Sekretny Sojusz) → Akt II (Radek Przebiegły) → Akt III (Narodziny Legendy) → Finał (Wejdź).
- Parallax (mysz + tilt telefonu), cząsteczki na canvasie, sceniczne przejścia. Wszystkie rAF/timery/listenery sprzątane przy odmontowaniu; respektuje `prefers-reduced-motion`.
